using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Pages
{
    public class AuthorModel : PageModel
    {
        private readonly PePrn25fallB1Context _context;

        public AuthorModel(PePrn25fallB1Context context)
        {
            _context = context;
        }
        // Create for <select>
        public SelectList BookList { get; set; }
        // List data need to display
        public IList<Author> Author { get; set; } = default!;
        [BindProperty(SupportsGet = true)]
        public int? SelectedBookId { get; set; }

        // Detail of a author
        public Author? AuthorDetail { get; set; }
        [BindProperty(SupportsGet = true)]
        public int? Id { get; set; } 

        public async Task<IActionResult> OnGetAsync()
        {
            if (Id == null)
            {
                var books = await _context.Books
                    .Select(b => new { b.BookId, b.Title })
                    .ToListAsync();

                var bookListWithAll = new List<object>
            {
                new {BookId = 0, Title = "All"}
            };
                bookListWithAll.AddRange(books);

                BookList = new SelectList(bookListWithAll, "BookId", "Title");


                var query = _context.Authors
                    .Include(m => m.Books).AsQueryable();

                if (SelectedBookId.HasValue && SelectedBookId != 0)
                {
                    query = query.Where(r => r.Books.Any(b => b.BookId == SelectedBookId.Value));
                }
                Author = await query.ToListAsync();
            }
            else
            {
                AuthorDetail = await _context.Authors
                    .Include(a => a.Books)
                    .FirstOrDefaultAsync(a => a.AuthorId == Id.Value);
                if (AuthorDetail == null)
                {
                    return NotFound();
                }
            }
            return Page();
        }
        public async Task<IActionResult> OnPostRemoveBookAsync(int authorId, int bookId)
        {
            var author = await _context.Authors
                .Include(a => a.Books)
                .FirstOrDefaultAsync(a => a.AuthorId == authorId);

            if (author == null)
            {
                return NotFound();
            }

            var book = author.Books.FirstOrDefault(b => b.BookId == bookId);
            if (book != null)
            {
                author.Books.Remove(book);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage(new { id = authorId });
        }
    }
}