﻿using System;
using System.Collections.Generic;

namespace Q2.Models;

public partial class Book
{
    public int BookId { get; set; }

    public string Title { get; set; } = null!;

    public int CategoryId { get; set; }

    public int? PublishedYear { get; set; }

    public decimal? Price { get; set; }

    public int? Quantity { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual ICollection<Author> Authors { get; set; } = new List<Author>();
}
