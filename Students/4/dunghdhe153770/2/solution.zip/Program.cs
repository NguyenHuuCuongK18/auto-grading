using Microsoft.EntityFrameworkCore;
using Q2.Models;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddRazorPages();
        var connectionStr = builder.Configuration.GetConnectionString("MyCnn");
        builder.Services.AddDbContext<PePrn25fallB1Context>(op =>
        {
            op.UseSqlServer(connectionStr);
        });

        builder.Services.AddSession();
        builder.Services.AddHttpContextAccessor();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        app.MapGet("/", context =>
        {
            context.Response.Redirect("/Author/List");
            return Task.CompletedTask;
        });

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthorization();

        app.MapRazorPages();

        app.UseSession();
        app.Run();
    }
}