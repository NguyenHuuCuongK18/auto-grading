using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class National
    {
        public int Index { get; set; }
        public string Name { get; set; }
    }
    public class ListModel : PageModel
    {

        private readonly PePrn25fallB1Context _context;
        public ListModel(PePrn25fallB1Context context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
        }

        [BindProperty]
        public National Filter { get; set; }


        public List<Q2.Models.Author> Authors { get; set; } = [];

        public List<Q2.Models.Book> Books { get; set; } = [];

        public List<National> Nationals { get; set; } = [];

        public List<SelectListItem> Items { get; set; } = [];

        public IActionResult OnGet()
        {
            int index = 1;
            Authors = _context.Authors.ToList();
            Books = _context.Books.Include(x => x.Category).ToList();
            foreach (var item in Authors)
            {
                if (Nationals.Find(x => x.Name == item.Nationality) != null) continue;
                Nationals.Add(new National
                {
                    Index = index++,
                    Name = item.Nationality
                });
            }
            return Page();
        }

        public IActionResult OnPost(int value)
        {
            int index = 1;
            Authors = _context.Authors.ToList();
            Books = _context.Books.Include(x => x.Category).ToList();
            foreach (var item in Authors)
            {
                if (Nationals.Find(x => x.Name == item.Nationality) != null) continue;
                Nationals.Add(new National
                {
                    Index = index++,
                    Name = item.Nationality
                });
            }

            return Page();
        }
    }
}
