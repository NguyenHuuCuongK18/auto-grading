﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Controllers
{
    public class AuthorController : Controller
    {
        private readonly PePrn25fallB1Context _context;
        public AuthorController(PePrn25fallB1Context context)
        {
            _context = context;
        }
        public IActionResult List(string? nationality)
        {
            var authors = _context.Authors.Include(b => b.Books).ToList();
            ViewBag.Nationality = authors.Select(b => b.Nationality).Distinct().ToList();
            if(nationality != null)
            {
                authors = authors.Where(b => b.Nationality.Equals(nationality)).ToList();
            }
            ViewBag.SelectedNationality = nationality;
            return View(authors);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateAuthor(string authorName, string nationality, int birthyear)
        {
            var author = new Author
            {
                AuthorName = authorName,
                Nationality = nationality,
                BirthYear = birthyear
            };
            _context.Authors.Add(author);
            _context.SaveChanges();
            return RedirectToAction("List");
        }
    }
}
