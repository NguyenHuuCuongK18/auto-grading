using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class CreateModel : PageModel
    {
        private readonly PePrn25fallB1Context _context;

        [BindProperty]
        public Models.Author Author { get; set; } = new();

        public CreateModel(PePrn25fallB1Context context)
        {
            _context = context;
        }

        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            _context.Authors.Add(Author);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Author/List");
        }
    }

}
