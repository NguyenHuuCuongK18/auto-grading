﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class ListModel : PageModel
    {
        private readonly PePrn25fallB1Context _context;
        public ListModel(PePrn25fallB1Context context)
        {
            _context = context;
        }
        public List<Models.Author> Authors { get; set; } = new();
        public List<string> Nationalities { get; set; } = new();
        public string? SelectedNationality { get; set; }

        public List<BookVM>? Books { get; set; }


        public async Task OnGetAsync()
        {
            // Lấy danh sách quốc tịch (distinct)
            Nationalities = await _context.Authors
                .Select(a => a.Nationality!)
                .Where(n => n != null && n != "")
                .Distinct()
                .OrderBy(n => n)
                .ToListAsync();

            var query = _context.Authors.AsQueryable();
     

            Authors = await query.ToListAsync();

            // Nếu chọn 1 tác giả thì hiển thị sách tương ứng
            //if (id.HasValue)
            //{
            //    Books = await _context.BookAuthors
            //        .Where(ba => ba.AuthorId == id.Value)
            //        .Include(ba => ba.Book)
            //            .ThenInclude(b => b.Category)
            //        .Select(ba => new BookVM
            //        {
            //            Title = ba.Book.Title,
            //            CategoryName = ba.Book.Category.CategoryName,
            //            PublishedYear = ba.Book.PublishedYear,
            //            Price = ba.Book.Price
            //        })
            //        .ToListAsync();
            //}
        }
        public async Task OnPostAsync(string? selectedNationality, int? id)
        {
            // Lấy danh sách quốc tịch (distinct)
            Nationalities = await _context.Authors
                .Select(a => a.Nationality!)
                .Where(n => n != null && n != "")
                .Distinct()
                .OrderBy(n => n)
                .ToListAsync();

            SelectedNationality = selectedNationality;

            // Lọc theo quốc tịch (nếu có)
            var query = _context.Authors.AsQueryable();
            if (!string.IsNullOrEmpty(selectedNationality))
            {
                query = query.Where(a => a.Nationality == selectedNationality);
            }

            Authors = await query.ToListAsync();
            ////Nếu chọn 1 tác giả thì hiển thị sách tương ứng
            //if (id.HasValue)
            //{
            //    Books = await _context.BookAuthors
            //        .Where(ba => ba.AuthorId == id.Value)
            //        .Include(ba => ba.Book)
            //            .ThenInclude(b => b.Category)
            //        .Select(ba => new BookVM
            //        {
            //            Title = ba.Book.Title,
            //            CategoryName = ba.Book.Category.CategoryName,
            //            PublishedYear = ba.Book.PublishedYear,
            //            Price = ba.Book.Price
            //        })
            //        .ToListAsync();
            //}
        }


    }
    public class BookVM
    {
        public int BookId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;
        public int? PublishedYear { get; set; }
        public decimal? Price { get; set; }
    }

}
