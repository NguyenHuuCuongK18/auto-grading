﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Q2.Data;

namespace Q2.Controllers
{
    public class AuthorController : Controller
    {
        private readonly PE_PRN_25FallB1Context _context;
        public AuthorController(PE_PRN_25FallB1Context context)
        {
            _context = context;
        }
        public IActionResult List()
        {
            ViewBag.Category = _context.Categories.ToList();
            var author = _context.Authors.Include(a => a.Books).ToList();
            return View(author);
        }

        public IActionResult Create()
        {
            var author = _context.Authors.ToList();

            return View(author);
        }
    }
}
