using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class CreateModel : PageModel
    {
        public PePrn25fallB1Context _context;
        public CreateModel(PePrn25fallB1Context context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public string? AuthorName { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? Nationality { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? BY { get; set; }

        public async Task OnGetAsync()
        {
        }

        public async Task OnPostAsync()
        {
        }
    }
}
