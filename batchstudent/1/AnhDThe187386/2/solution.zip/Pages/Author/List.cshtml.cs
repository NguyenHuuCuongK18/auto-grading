using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class ListModel : PageModel
    {
        public PePrn25fallB1Context _context;
        public ListModel(PePrn25fallB1Context context)
        {
            _context = context;
        }

        public List<string> Nationality = new List<string>();  
        public List<Q2.Models.Author> Authors { get; set; } = new List<Q2.Models.Author>();  
        public async Task OnGetAsync()
        {
            Authors = await _context.Authors.ToListAsync();
        }
    }
}
