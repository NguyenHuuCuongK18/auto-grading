using Microsoft.EntityFrameworkCore;
using Q2.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();

//Use the connection string below to connect to the database.
builder.Services.AddDbContext<PePrn25fallB1Context>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("MyCnn")));
var connectionStr = builder.Configuration.GetConnectionString("MyCnn");

var app = builder.Build();

app.MapRazorPages();
app.MapGet("/", () => "Hello World!");

app.Run();
