using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Q2.Models;

namespace Q2.Pages.Author
{
    public class ListModel : PageModel
    {
        private readonly PePrn25fallB1Context _context;

        public ListModel(PePrn25fallB1Context context)
        {
            _context = context;
        }

        public List<Models.Author> authors { get; set; }
        public void OnGet()
        {
            authors=_context.Authors.ToList();
        }
    }
}
