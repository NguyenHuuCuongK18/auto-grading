using Microsoft.EntityFrameworkCore;
using Q2.Data;

var builder = WebApplication.CreateBuilder(args);

// Use the connection string below to connect to the database.
var connectionStr = builder.Configuration.GetConnectionString("MyCnn");

// Register DbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(connectionStr));

// Register Razor Pages
builder.Services.AddRazorPages();

var app = builder.Build();

// Use exception page in development
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Error");
}

// Static files (wwwroot) if any
app.UseStaticFiles();

app.UseRouting();

// Map Razor Pages (this will include /Book -> List.cshtml, etc.)
app.MapRazorPages();

app.Run();