using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Q2.Pages
{
    public class DetailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
