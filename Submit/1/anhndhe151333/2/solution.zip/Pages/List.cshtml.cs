using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Q2.Data;
using Q2.Models;

namespace Q2.Pages
{
    public class ListModel : PageModel
    {
        private readonly AppDbContext _context;

        public ListModel(AppDbContext context)
        {
            _context = context;
        }

        // All authors for dropdown
        public List<Author> Authors { get; set; } = new();

        // Books (with their authors) to display
        public List<Book> Books { get; set; } = new();

        // Currently selected author id (nullable)
        [FromQuery(Name = "authorId")]
        public int? SelectedAuthorId { get; set; }

        public async Task OnGetAsync()
        {
            // Load authors for dropdown
            Authors = await _context.Authors
                .OrderBy(a => a.Name)
                .ToListAsync();

            // Base query: include authors
            IQueryable<Book> query = _context.Books
                .Include(b => b.Authors)
                .OrderBy(b => b.BookId);

            // Filter by author if provided and > 0
            if (SelectedAuthorId.HasValue && SelectedAuthorId.Value > 0)
            {
                int authorId = SelectedAuthorId.Value;
                query = query.Where(b => b.Authors.Any(a => a.AuthorId == authorId));
            }

            Books = await query.ToListAsync();
        }
    }
}